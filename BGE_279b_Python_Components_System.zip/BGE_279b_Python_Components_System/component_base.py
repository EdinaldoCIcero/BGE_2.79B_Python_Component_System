class KX_PythonComponent:

    def __init__(self, obj):
        self.object = obj

    def start(self, args):
        pass

    def update(self):
        pass